﻿using Dsw2025Tpi.Application.Dtos;
using Dsw2025Tpi.Domain.Entities;
using Dsw2025Tpi.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dsw2025Tpi.Application.Services
{
    public class ProductService
    {
        private readonly IRepository _repository;

        public ProductService(IRepository repository)
        {
            _repository = repository;
        }

        public async Task<ProductDto> CreateProductAsync(CreateProductDto dto)
        {
            // Validación 1: SKU único
            var existingProduct = await _repository.First<Product>(p => p.Sku == dto.Sku);
            if (existingProduct != null)
                throw new InvalidOperationException("SKU must be unique");

            // Validación 2: Precio positivo
            if (dto.CurrentUnitPrice <= 0)
                throw new ArgumentException("Price must be greater than 0");

            // Validación 3: Stock no negativo
            if (dto.StockQuantity < 0)
                throw new ArgumentException("Stock cannot be negative");

            var product = new Product
            {
                sku = dto.Sku,
                internalCode = dto.InternalCode,
                name = dto.Name,
                description = dto.Description,
                currentUnitPrice = dto.CurrentUnitPrice,
                stockQuantity = dto.StockQuantity
            };

            var createdProduct = await _repository.Add(product);

            return new ProductDto(
                createdProduct.Id,
                createdProduct.sku,
                createdProduct.internalCode,
                createdProduct.name,
                createdProduct.description,
                createdProduct.currentUnitPrice,
                createdProduct.stockQuantity,
                createdProduct.isActive
            );
        }
    }
}
