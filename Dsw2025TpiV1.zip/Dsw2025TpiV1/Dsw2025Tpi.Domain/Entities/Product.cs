﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dsw2025Tpi.Domain.Entities
{
    public class Product : EntityBase
    {
        public string sku {  get; set; } = string.Empty;
        public string internalCode { get; set; } = string.Empty;
        public string name { get; set; } = string.Empty;
        public string description { get; set; } = string.Empty;
        public decimal currentUnitPrice { get; set; }
        public int stockQuantity { get; set; }
        public bool isActive { get; set; } = true;

        public Product() {}
    }
}
