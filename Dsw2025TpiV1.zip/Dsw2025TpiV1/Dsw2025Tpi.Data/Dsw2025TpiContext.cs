﻿
using Dsw2025Tpi.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Dsw2025Tpi.Data;

public class Dsw2025TpiContext : DbContext
{
    public Dsw2025TpiContext(DbContextOptions<Dsw2025TpiContext> options)
            : base(options) { }

    public DbSet<Product> Products { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Configuración de Product
        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasIndex(p => p.sku).IsUnique(); // SKU único
            entity.Property(p => p.currentUnitPrice).HasColumnType("decimal(18,2)");
        });
    }

}