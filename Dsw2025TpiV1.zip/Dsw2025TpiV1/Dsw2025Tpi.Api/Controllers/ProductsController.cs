﻿using Microsoft.AspNetCore.Mvc;
using Dsw2025Tpi.Application.Services;
using Dsw2025Tpi.Application.Dtos;

namespace Dsw2025Tpi.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        private readonly ProductService _productService;

        public ProductsController(ProductService productService)
        {
            _productService = productService;
        }

        [HttpPost]
        public async Task<IActionResult> CreateProduct([FromBody] CreateProductDto dto)
        {
            try
            {
                var product = await _productService.CreateProductAsync(dto);
                return CreatedAtAction(nameof(GetProduct), new { id = product.Id }, product);
            }
            catch (InvalidOperationException ex) when (ex.Message.Contains("unique"))
            {
                return BadRequest(new { error = "SKU_DUPLICATED", message = "SKU must be unique" });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { error = "VALIDATION_ERROR", message = ex.Message });
            }
            catch (Exception)
            {
                return StatusCode(500, new { error = "SERVER_ERROR", message = "Internal server error" });
            }
        }

        [HttpGet("{id}")]
        public IActionResult GetProduct(Guid id)
        {
            // Implementación temporal para CreatedAtAction
            return Ok();
        }
    }
}
